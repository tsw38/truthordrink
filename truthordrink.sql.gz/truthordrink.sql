-- MySQL dump 10.13  Distrib 5.7.16, for osx10.12 (x86_64)
--
-- Host: localhost    Database: truthordare
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `responses`
--

DROP TABLE IF EXISTS `responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `responses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `truthID` int(11) NOT NULL,
  `answer` varchar(2) NOT NULL,
  `UUID_1` varchar(36) NOT NULL,
  `UUID_2` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `responses`
--

LOCK TABLES `responses` WRITE;
/*!40000 ALTER TABLE `responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `truths`
--

DROP TABLE IF EXISTS `truths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `truths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `truths`
--

LOCK TABLES `truths` WRITE;
/*!40000 ALTER TABLE `truths` DISABLE KEYS */;
INSERT INTO `truths` VALUES (1,'If you had to sleep with one person in this room, who would it be?'),(2,'What\'s the raunchiest porn you\'ve ever watched?'),(3,'What\'s the hardest drug you\'ve done?'),(4,'What\'s the most degrading thing you\'ve ever done during sex?'),(5,'Who\'s the most inappropriate person you\'ve ever fantasied about?'),(6,'What\'s the most embarrassing thing you\'ve ever done while drunk?'),(7,'What\'s the biggest lie you\'ve ever told a significant other?'),(8,'How many people in this room would you willingly bang?'),(9,'What\'s the most embarrassing item you\'ve ever used to get yourself off?'),(10,'What was the last thing you masturbated to?'),(11,'What\'s the #thing you would never want your parents to find out about you?'),(12,'What was the worst sex you ever had?'),(13,'What\'s the kinkiest thing you\'ve ever done?'),(14,'Which of your exes would you still be willing to sleep with?'),(15,'What\'s the biggest secret that you\'re keeping from everyone in this room?'),(16,'What\'s your magic number?'),(17,'What\'s the biggest age difference you\'ve had between yourself and a sexual partner?'),(18,'What\'s the kinkiest sex toy you\'ve ever used with a partner?'),(19,'What\'s the most scandalous location you\'ve had sex in?'),(20,'What\'s the most disgusting habit you have?'),(21,'What\'s the most embarrassing thing that\'s ever happened to you during sex?'),(22,'What\'s your biggest turn-on?'),(23,'What\'s your biggest turn-off?'),(24,'How long has your longest dry spell been?'),(25,'What – if any – amount of money would you be willing to have sex with a stranger for?'),(26,'What\'s the most embarrassing TV show that you watch?'),(27,'What\'s the furthest you\'ve gone sexually with a member of the same sex?'),(28,'Which sexual act are you best at?'),(29,'Which sexual act are you worst at?'),(30,'Are you more dominant or more submissive in bed?'),(31,'What\'s the dirtiest thing a partner\'s ever asked you to do?'),(32,'What\'s the most illegal thing you\'ve ever done?'),(33,'Where\'s the most inappropriate place you\'ve ever masturbated?'),(34,'What\'s the most desperate thing you\'ve ever done because you were horny?'),(35,'What\'s your most outrageous sexual fantasy?'),(36,'What was the last thing you cried over?'),(37,'How many sex toys do you own?'),(38,'What\'s the longest you\'ve gone without showering?'),(39,'What\'s the most embarrassing thing you\'ve ever been caught doing?'),(40,'How often do you fake orgasms?'),(41,'What\'s the hottest sex you\'ve ever had?'),(42,'What is your biggest sexual regret?'),(43,'What\'s the dirtiest sext you\'ve ever sent?'),(44,'What\'s something you\'ve done while drunk that you would never do sober?'),(45,'What\'s the closest you\'ve ever come to cheating?'),(46,'Who\'s the most scandalous person you\'ve had sex with?'),(47,'How many of the people you\'ve slept with did you meet online?'),(48,'What\'s the least amount of time you\'ve known someone for before sleeping with them?'),(49,'What\'s the most bizarre sexual role-play you\'ve ever participated in?'),(50,'Which of these questions would you be the most mortified to answer?');
/*!40000 ALTER TABLE `truths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `UUID` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'0d5827d7-aa73-49ad-a4c2-fc27a52a9498'),(2,'e6fdeb20-65d5-4d43-94ba-7f3171ba4cad'),(3,'88115e0c-69d7-41fa-b553-12d293c057f6'),(4,'c4e9e052-6bec-4b8b-a63b-8d5d817bd1e3'),(5,'4540a619-e8f7-4f5e-90a3-7516a216becf'),(6,'97b4de63-2329-417d-a54d-e22485e17519'),(7,'0d96d646-da55-4550-9f80-0faa25d4b9a8'),(8,'90de9483-c216-44bd-bfe2-1064335e3f8b'),(9,'6b016910-181f-4465-b49b-b65fc6c31891'),(10,'7ef8f15b-71ce-4b49-a49e-9cbf07477f99'),(11,'a78da0e6-01cb-44a6-88a8-6a789dcf2f92'),(12,'67c1c117-9c3c-4531-87cc-d9e0d0991d1a'),(13,'621adce1-eaa8-4178-95c3-1862115d4eb5');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-18  7:57:56
